-- sgc_dev.comunicaciones_factura definition

CREATE TABLE `comunicaciones_factura` (
  `comunicacionF_id` int NOT NULL AUTO_INCREMENT,
  `comunicacionF_factura_id` int NOT NULL,
  `comunicacionF_usuario_id` int NOT NULL,
  `comunicacionF` text COLLATE utf8mb3_spanish_ci,
  `comunicacionF_fechaIngreso` datetime NOT NULL,
  `comunicacionF_historial_id` int DEFAULT NULL,
  `comunicacionF_fechaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comunicacionF_modificada` tinyint NOT NULL,
  PRIMARY KEY (`comunicacionF_id`) USING BTREE,
  KEY `comunicacionF_factura_id` (`comunicacionF_factura_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=21972 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;