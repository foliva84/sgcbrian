-- sgc_dev.old_facturas definition

CREATE TABLE `old_facturas` (
  `factura_id` varchar(255) DEFAULT NULL,
  `factura_facturaEstado_id` varchar(255) DEFAULT NULL,
  `factura_caso_id` varchar(255) DEFAULT NULL,
  `factura_tipoFactura_id` varchar(255) DEFAULT NULL,
  `factura_numero` varchar(255) DEFAULT NULL,
  `factura_fechaIngresoSistema` varchar(255) DEFAULT NULL,
  `factura_fechaModificacion` varchar(255) DEFAULT NULL,
  `factura_fechaEmision` varchar(255) DEFAULT NULL,
  `factura_fechaRecepcion` varchar(255) DEFAULT NULL,
  `factura_fechaVencimiento` varchar(255) DEFAULT NULL,
  `factura_prioridad_id` varchar(255) DEFAULT NULL,
  `factura_pagador_id` varchar(255) DEFAULT NULL,
  `factura_monedaOrigen_id` varchar(255) DEFAULT NULL,
  `factura_importeMedicoOrigen` varchar(255) DEFAULT NULL,
  `factura_importeFeeOrigen` varchar(255) DEFAULT NULL,
  `factura_tipoCambio` varchar(255) DEFAULT NULL,
  `factura_importeUSD` varchar(255) DEFAULT NULL,
  `factura_importeAprobadoUSD` varchar(255) DEFAULT NULL,
  `factura_importeRechazadoUSD` varchar(255) DEFAULT NULL,
  `factura_fechaPago` varchar(255) DEFAULT NULL,
  `factura_formaPago_id` varchar(255) DEFAULT NULL,
  `facturas_pagoObservaciones` varchar(255) DEFAULT NULL,
  `factura_observaciones` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;