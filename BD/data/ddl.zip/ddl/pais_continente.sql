-- sgc_dev.pais_continente definition

CREATE TABLE `pais_continente` (
  `pais_id` int NOT NULL,
  `continente_id` int NOT NULL,
  PRIMARY KEY (`pais_id`,`continente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;