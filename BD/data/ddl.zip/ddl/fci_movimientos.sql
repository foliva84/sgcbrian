-- sgc_dev.fci_movimientos definition

CREATE TABLE `fci_movimientos` (
  `fciMov_id` int NOT NULL AUTO_INCREMENT,
  `fciMov_fcItem_id` int NOT NULL,
  `fciMov_usuario_id` int NOT NULL,
  `fciMov_fechaEvento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fciMov_fciMovEstado_id` int NOT NULL,
  `fciMov_facturaMotivoRechazo_id` int DEFAULT NULL,
  `fciMov_importeAprobadoUSD` decimal(11,2) DEFAULT NULL,
  `fciMov_importeAprobadoOrigen` decimal(11,2) DEFAULT NULL,
  `fciMov_fechaPago` date DEFAULT NULL,
  `fciMov_formaPago_id` int DEFAULT NULL,
  `fciMov_observaciones` tinytext,
  PRIMARY KEY (`fciMov_id`) USING BTREE,
  KEY `fciMov_fcItem_id` (`fciMov_fcItem_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=236201 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;