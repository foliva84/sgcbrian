-- sgc_dev.tipos_prestadores definition

CREATE TABLE `tipos_prestadores` (
  `tipoPrestador_id` int NOT NULL AUTO_INCREMENT,
  `tipoPrestador_nombre` varchar(40) NOT NULL,
  `tipoPrestador_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipoPrestador_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;