-- sgc_dev.ciudades definition

CREATE TABLE `ciudades` (
  `ciudad_id` int NOT NULL AUTO_INCREMENT,
  `ciudad_nombre` varchar(150) COLLATE utf8mb3_spanish_ci NOT NULL,
  `ciudad_pais_id` int NOT NULL,
  `ciudad_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`ciudad_id`) USING BTREE,
  KEY `ciudad_pais_id` (`ciudad_pais_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=19927 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;