-- sgc_dev.gop definition

CREATE TABLE `gop` (
  `gop_id` int NOT NULL AUTO_INCREMENT,
  `gop_casoNumero` int NOT NULL,
  `gop_voucher` varchar(30) COLLATE utf8mb3_spanish_ci NOT NULL,
  `gop_nombreBeneficiario` varchar(50) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_nacimientoBeneficiario` date DEFAULT NULL,
  `gop_edad` int DEFAULT NULL,
  `gop_sintomas` varchar(100) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_telefono` varchar(22) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_pais_id` int DEFAULT NULL,
  `gop_ciudad_id` int DEFAULT NULL,
  `gop_direccion` varchar(50) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_cp` varchar(10) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_hotel` varchar(50) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_habitacion` varchar(5) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_prestador_id` int DEFAULT NULL,
  `gop_prestadorEmail` varchar(150) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `gop_observaciones` text COLLATE utf8mb3_spanish_ci,
  `gop_fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gop_usuario_id` int DEFAULT NULL,
  PRIMARY KEY (`gop_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=60792 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;