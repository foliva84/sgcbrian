-- sgc_dev.re_tipos_avisotransferencia definition

CREATE TABLE `re_tipos_avisotransferencia` (
  `re_tipoAvisoTrans_id` int NOT NULL AUTO_INCREMENT,
  `re_tipoAvisoTrans_nombre` varchar(10) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`re_tipoAvisoTrans_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;