-- sgc_dev.accrued_lotes definition

CREATE TABLE `accrued_lotes` (
  `accruedLote_id` int NOT NULL AUTO_INCREMENT,
  `accruedLote_lote` int NOT NULL,
  `accruedLote_loteTipo_id` int NOT NULL,
  `accruedLote_estado_id` int NOT NULL,
  `accruedLote_fechaBorrador` datetime(6) NOT NULL,
  `accruedLote_fechaProcesado` datetime(6) DEFAULT NULL,
  `accruedLote_fechaInformado` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`accruedLote_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;