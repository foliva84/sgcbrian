-- sgc_dev.tipos_emails definition

CREATE TABLE `tipos_emails` (
  `tipoEmail_id` int NOT NULL AUTO_INCREMENT,
  `tipoEmail_nombre` varchar(100) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `tipoEmail_entidad` int NOT NULL,
  `tipoEmail_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipoEmail_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;