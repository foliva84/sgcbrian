-- sgc_dev.tipos_documentos definition

CREATE TABLE `tipos_documentos` (
  `tipoDocumento_id` int NOT NULL AUTO_INCREMENT,
  `tipoDocumento_nombre` varchar(5) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`tipoDocumento_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;