-- sgc_dev.reintegros_items_bak definition

CREATE TABLE `reintegros_items_bak` (
  `reintegroItem_id` int NOT NULL AUTO_INCREMENT,
  `reintegroItem_reintegro_id` int DEFAULT NULL,
  `reintegroItem_concepto_id` int NOT NULL,
  `reintegroItem_estado_id` int DEFAULT NULL,
  `reintegroItem_usuario_id` int NOT NULL,
  `reintegroItem_fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reintegroItem_importeOrigen` decimal(11,2) NOT NULL,
  `reintegroItem_moneda_id` int NOT NULL,
  `reintegroItem_monedaTC` decimal(6,2) NOT NULL,
  `reintegroItem_importeUSD` decimal(11,2) NOT NULL,
  `reintegroItem_importeAprobadoUSD` decimal(11,2) DEFAULT NULL,
  `reintegroItem_observaciones` tinytext COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`reintegroItem_id`) USING BTREE,
  KEY `reintegroItem_reintegro_id` (`reintegroItem_reintegro_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3321 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;