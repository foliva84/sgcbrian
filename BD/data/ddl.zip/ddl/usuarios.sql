-- sgc_dev.usuarios definition

CREATE TABLE `usuarios` (
  `usuario_id` int NOT NULL AUTO_INCREMENT,
  `usuario_usuario` varchar(16) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario_password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario_nombre` varchar(120) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario_apellido` varchar(120) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `usuario_activo` tinyint(1) NOT NULL,
  `usuario_ultimo_acceso` datetime NOT NULL,
  `usuario_fecha_baja` datetime NOT NULL,
  `usuario_fecha_alta` datetime NOT NULL,
  `usuario_fecha_modificacion` datetime NOT NULL,
  `usuario_fecha_reactivacion` datetime NOT NULL,
  `usuario_alta_usuario_id` int NOT NULL,
  `usuario_baja_usuario_id` int NOT NULL,
  `usuario_modificacion_usuario_id` int NOT NULL,
  `usuario_reactivacion_usuario_id` int NOT NULL,
  `usuario_rol_id` int NOT NULL,
  PRIMARY KEY (`usuario_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;