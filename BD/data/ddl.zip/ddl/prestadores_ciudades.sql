-- sgc_dev.prestadores_ciudades definition

CREATE TABLE `prestadores_ciudades` (
  `prestadorCiudad_id` int NOT NULL AUTO_INCREMENT,
  `prestadorCiudad_ciudad_id` int NOT NULL,
  `prestadorCiudad_prestador_id` int NOT NULL,
  PRIMARY KEY (`prestadorCiudad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=986 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;