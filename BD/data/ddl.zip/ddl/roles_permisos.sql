-- sgc_dev.roles_permisos definition

CREATE TABLE `roles_permisos` (
  `rol_permiso_id` int NOT NULL AUTO_INCREMENT,
  `rol_id` int NOT NULL,
  `permiso_id` int NOT NULL,
  PRIMARY KEY (`rol_permiso_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=937 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;