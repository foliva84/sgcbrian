-- sgc_dev.ri_estados definition

CREATE TABLE `ri_estados` (
  `riEstado_id` int NOT NULL AUTO_INCREMENT,
  `riEstado_nombre` varchar(30) COLLATE utf8mb3_spanish_ci NOT NULL,
  `riEstado_sector` varchar(30) COLLATE utf8mb3_spanish_ci NOT NULL,
  `riEstado_descripcion` varchar(50) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`riEstado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;