-- sgc_dev.practicas definition

CREATE TABLE `practicas` (
  `practica_id` int NOT NULL AUTO_INCREMENT,
  `practica_nombre` varchar(60) COLLATE utf8mb3_spanish_ci NOT NULL,
  `practica_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`practica_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;