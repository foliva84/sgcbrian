-- sgc_dev.ri_movimientos definition

CREATE TABLE `ri_movimientos` (
  `riMov_id` int NOT NULL AUTO_INCREMENT,
  `riMov_reintegroItem_id` int NOT NULL,
  `riMov_riEstado_id` int NOT NULL,
  `riMov_fechaEvento` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `riMov_importeAprobadoUSD` decimal(11,2) DEFAULT NULL,
  `riMov_riMotivoRechazo_id` int DEFAULT NULL,
  `riMov_fechaPago` date DEFAULT NULL,
  `riMov_formaPago_id` int DEFAULT NULL,
  `riMov_observaciones` tinytext COLLATE utf8mb3_spanish_ci,
  `riMov_usuario_id` int NOT NULL,
  PRIMARY KEY (`riMov_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=56878 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;