-- sgc_dev.fc_items_bak definition

CREATE TABLE `fc_items_bak` (
  `fcItem_id` int NOT NULL AUTO_INCREMENT,
  `fcItem_factura_id` int NOT NULL,
  `fcItem_caso_id` int NOT NULL,
  `fcItem_clientePagador_id` int NOT NULL,
  `fcItem_usuario_id` int NOT NULL,
  `fcItem_estado_id` int NOT NULL,
  `fcItem_accruedLote_id` int DEFAULT NULL,
  `fcItem_ordenPago_id` int DEFAULT NULL,
  `fcItem_fechaIngresoSistema` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fcItem_monedaOrigen_id` int NOT NULL,
  `fcItem_importeMedicoOrigen` decimal(11,2) NOT NULL,
  `fcItem_importeFeeOrigen` decimal(11,2) DEFAULT NULL,
  `fcItem_descuento` decimal(11,2) NOT NULL,
  `fcItem_tipoCambio` decimal(6,2) NOT NULL,
  `fcItem_importeUSD` decimal(11,2) NOT NULL,
  `fcItem_importeAprobadoUSD` decimal(11,2) DEFAULT NULL,
  `fcItem_importeAprobadoOrigen` decimal(11,2) DEFAULT NULL,
  `fcItem_observaciones` tinytext,
  PRIMARY KEY (`fcItem_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7747 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;