-- sgc_dev.reintegros_agenda definition

CREATE TABLE `reintegros_agenda` (
  `reintegroAgenda_id` int NOT NULL AUTO_INCREMENT,
  `reintegroAgenda_reintegro_id` int NOT NULL,
  `reintegroAgenda_usuarioAsigna_id` int NOT NULL,
  `reintegroAgenda_usuarioAsignado_id` int NOT NULL,
  `reintegroAgenda_fechaAsignacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`reintegroAgenda_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;