-- sgc_dev.servicios definition

CREATE TABLE `servicios` (
  `servicio_id` int NOT NULL AUTO_INCREMENT,
  `servicio_caso_id` int NOT NULL,
  `servicio_usuario_id` int NOT NULL,
  `servicio_prestador_id` int NOT NULL,
  `servicio_practica_id` int NOT NULL,
  `servicio_moneda_id` int NOT NULL,
  `servicio_fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `servicio_fechaUltimaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `servicio_presuntoOrigen` decimal(11,2) NOT NULL,
  `servicio_tipoCambio` decimal(6,2) NOT NULL,
  `servicio_presuntoUSD` decimal(11,2) NOT NULL,
  `servicio_autorizado` tinyint(1) NOT NULL,
  `servicio_casoManual` tinyint(1) NOT NULL,
  `servicio_cargaFueraCobertura` tinyint(1) DEFAULT NULL,
  `servicio_justificacion` varchar(70) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `servicio_sistemaAntiguo` tinyint(1) DEFAULT NULL,
  `servicio_cancelado` tinyint(1) NOT NULL DEFAULT '0',
  `servicio_confirmado` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`servicio_id`) USING BTREE,
  KEY `servicio_caso_id` (`servicio_caso_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=100950 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;