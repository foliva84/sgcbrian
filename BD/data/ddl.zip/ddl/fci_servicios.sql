-- sgc_dev.fci_servicios definition

CREATE TABLE `fci_servicios` (
  `fciServicio_id` int NOT NULL AUTO_INCREMENT,
  `fciServicio_fcItem_id` int NOT NULL,
  `fciServicio_servicio_id` int NOT NULL,
  `fciServicio_factura_id` int NOT NULL,
  PRIMARY KEY (`fciServicio_id`) USING BTREE,
  KEY `fciServicio_fcItem_id` (`fciServicio_fcItem_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=54940 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;