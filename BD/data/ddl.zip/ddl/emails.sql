-- sgc_dev.emails definition

CREATE TABLE `emails` (
  `email_id` int NOT NULL AUTO_INCREMENT,
  `email_entidad_id` int NOT NULL,
  `email_entidad_tipo` int NOT NULL,
  `email_tipoEmail_id` int NOT NULL,
  `email_nombre` varchar(100) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `email_email` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `email_principal` tinyint(1) NOT NULL,
  PRIMARY KEY (`email_id`) USING BTREE,
  KEY `email_entidad_id` (`email_entidad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=91339 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;