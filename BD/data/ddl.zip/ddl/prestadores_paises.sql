-- sgc_dev.prestadores_paises definition

CREATE TABLE `prestadores_paises` (
  `prestadorPais_id` int NOT NULL AUTO_INCREMENT,
  `prestadorPais_pais_id` int NOT NULL,
  `prestadorPais_prestador_id` int NOT NULL,
  PRIMARY KEY (`prestadorPais_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=717 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;