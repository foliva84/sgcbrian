-- sgc_dev.paises definition

CREATE TABLE `paises` (
  `pais_id` int NOT NULL AUTO_INCREMENT,
  `pais_alfa3` varchar(3) COLLATE utf8mb3_spanish_ci NOT NULL,
  `pais_alfa2` varchar(2) COLLATE utf8mb3_spanish_ci NOT NULL,
  `pais_nombreEspanol` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `pais_nombreIngles` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `pais_capital` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `pais_codigoTel` int NOT NULL,
  `pais_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`pais_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=261 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;