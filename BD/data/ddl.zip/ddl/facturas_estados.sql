-- sgc_dev.facturas_estados definition

CREATE TABLE `facturas_estados` (
  `facturaEstado_id` int NOT NULL AUTO_INCREMENT,
  `facturaEstado_nombre` varchar(40) NOT NULL,
  PRIMARY KEY (`facturaEstado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;