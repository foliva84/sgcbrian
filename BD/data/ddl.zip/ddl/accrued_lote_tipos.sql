-- sgc_dev.accrued_lote_tipos definition

CREATE TABLE `accrued_lote_tipos` (
  `accruedLoteTipo_id` int NOT NULL AUTO_INCREMENT,
  `accruedLoteTipo_nombre` varchar(10) NOT NULL,
  PRIMARY KEY (`accruedLoteTipo_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;