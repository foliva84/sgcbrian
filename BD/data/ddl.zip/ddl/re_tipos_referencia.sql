-- sgc_dev.re_tipos_referencia definition

CREATE TABLE `re_tipos_referencia` (
  `re_tipoReferencia_id` int NOT NULL AUTO_INCREMENT,
  `re_tipoReferencia_nombre` varchar(10) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`re_tipoReferencia_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;