-- sgc_dev.comunicaciones_asunto_tipos definition

CREATE TABLE `comunicaciones_asunto_tipos` (
  `asunto_tipo_id` tinyint DEFAULT NULL,
  `asunto_tipo_nombre` varchar(15) COLLATE utf8mb3_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;