-- sgc_dev.diagnostico_categoria definition

CREATE TABLE `diagnostico_categoria` (
  `diagnostico_inicio_id` int NOT NULL,
  `categoria_diagnostico_id` int NOT NULL,
  PRIMARY KEY (`diagnostico_inicio_id`,`categoria_diagnostico_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;