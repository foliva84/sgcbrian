-- sgc_dev.formas_pagos definition

CREATE TABLE `formas_pagos` (
  `formaPago_id` int NOT NULL AUTO_INCREMENT,
  `formaPago_nombre` varchar(50) NOT NULL,
  `formaPago_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`formaPago_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;