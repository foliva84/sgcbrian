-- sgc_dev.prestadores_prioridades definition

CREATE TABLE `prestadores_prioridades` (
  `prestadorPrioridad_id` int NOT NULL AUTO_INCREMENT,
  `prestadorPrioridad_nombre` varchar(100) NOT NULL,
  `prestadorPrioridad_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`prestadorPrioridad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;