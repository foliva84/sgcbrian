-- sgc_dev.casos_agenda definition

CREATE TABLE `casos_agenda` (
  `casoAgenda_id` int NOT NULL AUTO_INCREMENT,
  `casoAgenda_caso_id` int NOT NULL,
  `casoAgenda_usuarioAsigna_id` int NOT NULL,
  `casoAgenda_usuarioAsignado_id` int NOT NULL,
  `casoAgenda_fechaAsignacion` datetime NOT NULL,
  PRIMARY KEY (`casoAgenda_id`) USING BTREE,
  KEY `casoAgenda_caso_id` (`casoAgenda_caso_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=89262 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;