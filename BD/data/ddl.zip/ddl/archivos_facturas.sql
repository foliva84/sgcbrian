-- sgc_dev.archivos_facturas definition

CREATE TABLE `archivos_facturas` (
  `archivo_id` int NOT NULL AUTO_INCREMENT,
  `archivo_nombre` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `archivo_extension` varchar(4) COLLATE utf8mb3_spanish_ci NOT NULL,
  `archivo_encriptado` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `factura_id` int NOT NULL,
  `usuario_id` int NOT NULL,
  `archivo_fecha` date NOT NULL,
  PRIMARY KEY (`archivo_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51658 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;