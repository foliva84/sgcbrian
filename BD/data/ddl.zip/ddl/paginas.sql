-- sgc_dev.paginas definition

CREATE TABLE `paginas` (
  `pagina_id` int NOT NULL AUTO_INCREMENT,
  `pagina_nombre` varchar(50) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`pagina_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;