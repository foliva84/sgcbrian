-- sgc_dev.comunicaciones_asuntos definition

CREATE TABLE `comunicaciones_asuntos` (
  `comunicacionAsunto_id` int NOT NULL AUTO_INCREMENT,
  `comunicacionAsunto_nombre` varchar(100) NOT NULL,
  `comunicacionAsunto_activo` tinyint(1) NOT NULL,
  `comunicacionAsunto_color` varchar(10) NOT NULL,
  `comunicacionAsunto_tipo_id` tinyint(1) NOT NULL,
  PRIMARY KEY (`comunicacionAsunto_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;