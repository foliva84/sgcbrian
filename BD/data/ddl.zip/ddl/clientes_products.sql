-- sgc_dev.clientes_products definition

CREATE TABLE `clientes_products` (
  `clienteProduct_id` int NOT NULL AUTO_INCREMENT,
  `clienteProduct_product_id` int NOT NULL,
  `clienteProduct_cliente_id` int NOT NULL,
  PRIMARY KEY (`clienteProduct_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1232 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;