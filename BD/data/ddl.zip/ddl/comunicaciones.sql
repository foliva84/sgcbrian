-- sgc_dev.comunicaciones definition

CREATE TABLE `comunicaciones` (
  `comunicacion_id` int NOT NULL AUTO_INCREMENT,
  `comunicacion_caso_id` int NOT NULL,
  `comunicacion_casoEstado_id` int NOT NULL,
  `comunicacion_asunto_id` int NOT NULL,
  `comunicacion_usuario_id` int NOT NULL,
  `comunicacion` text COLLATE utf8mb3_spanish_ci,
  `comunicacion_fechaIngreso` datetime NOT NULL,
  `comunicacion_historial_id` int DEFAULT NULL,
  `comunicacion_fechaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comunicacion_modificada` tinyint(1) NOT NULL,
  `comunicacion_sistemaAntiguo` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`comunicacion_id`) USING BTREE,
  KEY `caso_id` (`comunicacion_caso_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=680983 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;