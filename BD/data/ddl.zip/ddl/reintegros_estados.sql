-- sgc_dev.reintegros_estados definition

CREATE TABLE `reintegros_estados` (
  `reintegroEstado_id` int NOT NULL AUTO_INCREMENT,
  `reintegroEstado_nombre` varchar(40) COLLATE utf8mb3_spanish_ci NOT NULL,
  `reintegroEstado_orden` int NOT NULL,
  PRIMARY KEY (`reintegroEstado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;