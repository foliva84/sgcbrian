-- sgc_dev.coverage definition

CREATE TABLE `coverage` (
  `coverage_id` int NOT NULL AUTO_INCREMENT,
  `voucher_id` int NOT NULL,
  `se_id` int NOT NULL,
  `coverage_name` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `coverage_val` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`coverage_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3234323 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;