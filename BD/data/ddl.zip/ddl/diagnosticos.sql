-- sgc_dev.diagnosticos definition

CREATE TABLE `diagnosticos` (
  `diagnostico_id` int NOT NULL AUTO_INCREMENT,
  `diagnostico_codigoICD` varchar(10) COLLATE utf8mb3_spanish_ci NOT NULL,
  `diagnostico_nombre` varchar(300) COLLATE utf8mb3_spanish_ci NOT NULL,
  `diagnostico_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`diagnostico_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27092 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;