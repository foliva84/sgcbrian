-- sgc_dev.continentes definition

CREATE TABLE `continentes` (
  `continente_id` int NOT NULL,
  `continente_nombreEspanol` varchar(100) DEFAULT NULL,
  `continente_nombreIngles` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`continente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;