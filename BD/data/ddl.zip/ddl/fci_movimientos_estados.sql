-- sgc_dev.fci_movimientos_estados definition

CREATE TABLE `fci_movimientos_estados` (
  `fciMovEstado_id` int NOT NULL AUTO_INCREMENT,
  `fciMovEstado_nombre` varchar(40) NOT NULL,
  `fciMovEstado_sector` varchar(30) NOT NULL,
  `fciMovEstado_descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`fciMovEstado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;