-- sgc_dev.prestadores_contratos definition

CREATE TABLE `prestadores_contratos` (
  `prestadorContrato_id` int NOT NULL AUTO_INCREMENT,
  `prestadorContrato_nombre` varchar(100) NOT NULL,
  `prestadorContrato_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`prestadorContrato_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;