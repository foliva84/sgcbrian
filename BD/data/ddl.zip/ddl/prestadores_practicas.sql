-- sgc_dev.prestadores_practicas definition

CREATE TABLE `prestadores_practicas` (
  `prestadorPractica_id` int NOT NULL AUTO_INCREMENT,
  `prestadorPractica_practica_id` int NOT NULL,
  `prestadorPractica_prestador_id` int NOT NULL,
  `presuntoOrigen` decimal(11,2) NOT NULL,
  PRIMARY KEY (`prestadorPractica_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3211 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;