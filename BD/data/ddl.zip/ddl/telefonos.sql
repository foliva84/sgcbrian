-- sgc_dev.telefonos definition

CREATE TABLE `telefonos` (
  `telefono_id` int NOT NULL AUTO_INCREMENT,
  `telefono_entidad_id` int NOT NULL,
  `telefono_entidad_tipo` int NOT NULL,
  `telefono_tipoTelefono_id` int NOT NULL,
  `telefono_numero` varchar(25) COLLATE utf8mb3_spanish_ci NOT NULL,
  `telefono_principal` tinyint(1) NOT NULL,
  PRIMARY KEY (`telefono_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=137044 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;