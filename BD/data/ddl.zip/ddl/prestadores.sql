-- sgc_dev.prestadores definition

CREATE TABLE `prestadores` (
  `prestador_id` int NOT NULL AUTO_INCREMENT,
  `prestador_tipoPrestador_id` int NOT NULL,
  `prestador_prestadorPrioridad_id` int NOT NULL,
  `prestador_direccion` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_codigoPostal` varchar(10) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `prestador_pais_id` int NOT NULL,
  `prestador_ciudad_id` int NOT NULL,
  `prestador_nombre` varchar(75) COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_razonSocial` varchar(75) COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_paginaWeb` varchar(40) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `prestador_contrato_id` int DEFAULT NULL,
  `prestador_contratoObservaciones` text COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_bancoIntermediario` tinytext COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_bancoBeneficiario` tinytext COLLATE utf8mb3_spanish_ci NOT NULL,
  `prestador_taxID` varchar(40) COLLATE utf8mb3_spanish_ci DEFAULT NULL,
  `prestador_inicioActividades` date DEFAULT NULL,
  `prestador_observaciones` mediumtext COLLATE utf8mb3_spanish_ci,
  `prestador_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`prestador_id`) USING BTREE,
  KEY `prestador_tipoPrestador_id` (`prestador_tipoPrestador_id`,`prestador_pais_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1125 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;