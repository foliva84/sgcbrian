-- sgc_dev.fci_motivos_rechazos definition

CREATE TABLE `fci_motivos_rechazos` (
  `fciMotivoRechazo_id` int NOT NULL AUTO_INCREMENT,
  `fciMotivoRechazo_descripcion` varchar(50) NOT NULL,
  PRIMARY KEY (`fciMotivoRechazo_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;