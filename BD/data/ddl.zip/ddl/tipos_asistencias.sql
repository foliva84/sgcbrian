-- sgc_dev.tipos_asistencias definition

CREATE TABLE `tipos_asistencias` (
  `tipoAsistencia_id` int NOT NULL AUTO_INCREMENT,
  `tipoAsistencia_clasificacion_id` int NOT NULL,
  `tipoAsistencia_nombre` varchar(200) COLLATE utf8mb3_spanish_ci NOT NULL,
  `tipoAsistencia_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipoAsistencia_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;