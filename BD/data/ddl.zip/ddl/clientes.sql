-- sgc_dev.clientes definition

CREATE TABLE `clientes` (
  `cliente_id` int NOT NULL AUTO_INCREMENT,
  `cliente_tipoCliente_id` int NOT NULL,
  `cliente_pais_id` int NOT NULL,
  `cliente_ciudad_id` int NOT NULL,
  `cliente_nombre` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `cliente_razonSocial` varchar(60) CHARACTER SET utf8mb3 COLLATE utf8mb3_spanish_ci NOT NULL,
  `cliente_abreviatura` varchar(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci NOT NULL,
  `cliente_paginaWeb` varchar(40) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `cliente_direccion` varchar(60) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `cliente_codigoPostal` varchar(10) CHARACTER SET latin1 COLLATE latin1_spanish_ci DEFAULT NULL,
  `cliente_observaciones` tinytext CHARACTER SET latin1 COLLATE latin1_spanish_ci,
  `cliente_modifica` tinyint(1) NOT NULL DEFAULT '1',
  `cliente_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`cliente_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;