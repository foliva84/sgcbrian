-- sgc_dev.ri_motivos_rechazos definition

CREATE TABLE `ri_motivos_rechazos` (
  `riMotivoRechazo_id` int NOT NULL AUTO_INCREMENT,
  `riMotivoRechazo_descripcion` varchar(30) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`riMotivoRechazo_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;