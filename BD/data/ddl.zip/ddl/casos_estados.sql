-- sgc_dev.casos_estados definition

CREATE TABLE `casos_estados` (
  `casoEstado_id` int NOT NULL AUTO_INCREMENT,
  `casoEstado_nombre` varchar(30) NOT NULL,
  `casoEstado_orden` int NOT NULL,
  PRIMARY KEY (`casoEstado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;