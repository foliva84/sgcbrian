-- sgc_dev.monedas definition

CREATE TABLE `monedas` (
  `moneda_id` int NOT NULL AUTO_INCREMENT,
  `moneda_nombre` varchar(3) COLLATE utf8mb3_spanish_ci NOT NULL,
  `moneda_descripcion` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `moneda_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`moneda_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;