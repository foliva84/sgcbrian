-- sgc_dev.accrued_estados definition

CREATE TABLE `accrued_estados` (
  `accrued_estado_id` int NOT NULL AUTO_INCREMENT,
  `accrued_estado_nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`accrued_estado_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;