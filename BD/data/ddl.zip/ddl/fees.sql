-- sgc_dev.fees definition

CREATE TABLE `fees` (
  `fee_id` int NOT NULL AUTO_INCREMENT,
  `fee_nombre` varchar(100) NOT NULL,
  `fee_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`fee_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;