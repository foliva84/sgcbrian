-- sgc_dev.facturas_prioridades definition

CREATE TABLE `facturas_prioridades` (
  `facturaPrioridad_id` int NOT NULL AUTO_INCREMENT,
  `facturaPrioridad_nombre` varchar(20) NOT NULL,
  `facturaPrioridad_activa` tinyint(1) NOT NULL,
  PRIMARY KEY (`facturaPrioridad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;