-- sgc_dev.tipos_facturas definition

CREATE TABLE `tipos_facturas` (
  `tipoFactura_id` int NOT NULL AUTO_INCREMENT,
  `tipoFactura_nombre` varchar(3) NOT NULL,
  `tipoFactura_descripcion` varchar(20) NOT NULL,
  `tipoFactura_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipoFactura_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;