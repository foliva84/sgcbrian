-- sgc_dev.tipos_clientes definition

CREATE TABLE `tipos_clientes` (
  `tipoCliente_id` int NOT NULL AUTO_INCREMENT,
  `tipoCliente_nombre` varchar(40) NOT NULL,
  `tipoCliente_activo` tinyint NOT NULL,
  PRIMARY KEY (`tipoCliente_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;