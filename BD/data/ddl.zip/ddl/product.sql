-- sgc_dev.product definition

CREATE TABLE `product` (
  `product_id_interno` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `product_se_id` int NOT NULL,
  `product_activo` int NOT NULL,
  PRIMARY KEY (`product_id_interno`) USING BTREE,
  UNIQUE KEY `unique_product` (`product_id_interno`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1353 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;