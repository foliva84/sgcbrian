-- sgc_dev.roles definition

CREATE TABLE `roles` (
  `rol_id` int NOT NULL AUTO_INCREMENT,
  `rol_nombre` varchar(100) COLLATE utf8mb3_spanish_ci NOT NULL,
  `rol_orden` int NOT NULL,
  `rol_jerarquia` int NOT NULL,
  PRIMARY KEY (`rol_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;