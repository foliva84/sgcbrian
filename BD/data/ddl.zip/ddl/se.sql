-- sgc_dev.se definition

CREATE TABLE `se` (
  `se_id` int NOT NULL AUTO_INCREMENT,
  `se_nombre` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `se_url_voucher` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  `se_url_producto` varchar(255) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`se_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;