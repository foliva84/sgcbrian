-- sgc_dev.tipos_telefonos definition

CREATE TABLE `tipos_telefonos` (
  `tipoTelefono_id` int NOT NULL AUTO_INCREMENT,
  `tipoTelefono_nombre` varchar(100) NOT NULL,
  `tipoTelefono_entidad` int NOT NULL,
  `tipoTelefono_activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`tipoTelefono_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;