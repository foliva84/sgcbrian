-- sgc_dev.ri_conceptos definition

CREATE TABLE `ri_conceptos` (
  `riConcepto_id` int NOT NULL AUTO_INCREMENT,
  `riConcepto_nombre` varchar(40) COLLATE utf8mb3_spanish_ci NOT NULL,
  PRIMARY KEY (`riConcepto_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;