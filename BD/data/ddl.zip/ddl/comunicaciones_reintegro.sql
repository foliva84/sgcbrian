-- sgc_dev.comunicaciones_reintegro definition

CREATE TABLE `comunicaciones_reintegro` (
  `comunicacionR_id` int NOT NULL AUTO_INCREMENT,
  `comunicacionR_reintegro_id` int NOT NULL,
  `comunicacionR_usuario_id` int NOT NULL,
  `comunicacionR` text COLLATE utf8mb3_spanish_ci,
  `comunicacionR_fechaIngreso` datetime NOT NULL,
  `comunicacionR_historial_id` int DEFAULT NULL,
  `comunicacionR_fechaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `comunicacionR_modificada` tinyint NOT NULL,
  PRIMARY KEY (`comunicacionR_id`) USING BTREE,
  KEY `comunicacionR_reintegro_id` (`comunicacionR_reintegro_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=273454 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_spanish_ci ROW_FORMAT=COMPACT;