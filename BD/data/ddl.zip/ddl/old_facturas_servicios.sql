-- sgc_dev.old_facturas_servicios definition

CREATE TABLE `old_facturas_servicios` (
  `facturaServicio_id` int NOT NULL AUTO_INCREMENT,
  `facturaServicio_factura_id` int NOT NULL,
  `facturaServicio_servicio_id` int NOT NULL,
  PRIMARY KEY (`facturaServicio_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;