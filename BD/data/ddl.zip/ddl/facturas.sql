-- sgc_dev.facturas definition

CREATE TABLE `facturas` (
  `factura_Id` int NOT NULL AUTO_INCREMENT,
  `factura_prestador_id` int NOT NULL,
  `factura_facturaEstado_id` int NOT NULL,
  `factura_numero` varchar(15) NOT NULL,
  `factura_prioridad_id` int NOT NULL,
  `factura_usuario_id` int NOT NULL,
  `factura_pagador_id` int DEFAULT NULL,
  `factura_fechaIngresoSistema` datetime NOT NULL,
  `factura_fechaModificacion` datetime NOT NULL,
  `factura_fechaEmision` date NOT NULL,
  `factura_fechaRecepcion` date NOT NULL,
  `factura_fechaVencimiento` date NOT NULL,
  `factura_observaciones` tinytext NOT NULL,
  PRIMARY KEY (`factura_Id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=28685 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;